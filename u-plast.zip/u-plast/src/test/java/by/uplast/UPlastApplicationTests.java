package by.uplast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UPlastApplicationTests {

	@Test
	void contextLoads() {
	}

}
